package com.zg.onlinegame.entity;

public class MsgType {
    public final static int MSG_CMD_ROOM_INFO = 1;//告知当前房间信息
    public final static int MSG_CHG_SPEECH_STATE = 2;//告知当前是否关麦、开麦
    public final static int MSG_BOARD = 3;//告知当前棋盘相关信息

}
