package com.zg.onlinegame.activity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import im.zego.zegoexpress.entity.ZegoStream;
import im.zego.zegoexpress.entity.ZegoUser;


import com.zg.onlinegame.R;
import com.zg.onlinegame.chess.Chess;
import com.zg.onlinegame.chess.Chessboard;
import com.zg.onlinegame.entity.Msg;
import com.zg.onlinegame.entity.MsgBoard;
import com.zg.onlinegame.entity.MsgType;
import com.zg.onlinegame.entity.RoomInfo;
import com.zg.onlinegame.utils.ShowUtils;
import com.zg.onlinegame.view.ChessView;
import com.zg.onlinegame.zego.MyServer;
import com.zg.onlinegame.zego.Zego;

import java.util.ArrayList;
import java.util.Random;

public class ChessActivity extends BaseServerEventActivity implements ShowUtils.OnClickOkListener {
    private final static String TAG = "ChessActivity";
    // views
    private TextView tipTV;
    private TextView mRoomNameTV;
    private ChessView chessView;

    // user info
    private String mRoomId;
    private String mRoomName;
    private boolean mIsMaster;
    private String mUserName;
    private String mUserId;

    private ImageView mOtherUserHeader;
    private ImageView mMyHeader;

    private ArrayList<ZegoUser> userList = new ArrayList<>();

    // roomInfo
    private RoomInfo mRoomInfo;

    //
    private MyServer mMyserver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLoading("正在连接...");
        loadCfg();
        setContentView(R.layout.activity_chess);
        initViews();
        initObjects();
        //自己进入房间，为总数加1
        chessView.updateUserCount(1);

        mMyserver.getToken(mUserId, mRoomId);
        Log.e(TAG, "onCreate");


    }

    /**
     * 初始化相关视图
     */
    private void initViews() {
        tipTV = findViewById(R.id.tip);
        FrameLayout root = findViewById(R.id.rootView);

        Chessboard board = new Chessboard(mIsMaster, 20);
        chessView = new ChessView(this, board);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        chessView.setLayoutParams(params);
        root.addView(chessView, 0);


        mOtherUserHeader = findViewById(R.id.otherUserHeader);
        mMyHeader = findViewById(R.id.myHeader);

        mRoomNameTV = findViewById(R.id.roomName);
        mRoomNameTV.setText(mRoomName + "(" + mRoomId + ")");
        findViewById(R.id.closeBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    /**
     * 加载来自登录界面传入的用户信息
     */
    private void loadCfg() {
        Intent intent = getIntent();
        mRoomName = intent.getStringExtra("roomName");
        mRoomId = intent.getStringExtra("roomId");
        mRoomName = intent.getStringExtra("roomName");
        mIsMaster = intent.getBooleanExtra("isMaster", false);
        mUserId = intent.getStringExtra("userId");
        mUserName = intent.getStringExtra("userName");

    }

    /**
     * 初始化必要的类对象
     */
    private void initObjects() {
        mMyserver = MyServer.getInstance();
        mMyserver.setServerListener(this);
        if (mIsMaster) {
            mRoomInfo = new RoomInfo(MsgType.MSG_CMD_ROOM_INFO, mUserId, mRoomId, mRoomName, mUserId, false, false);
            showTip("等待对手");
            chessView.clearChess();
        }

        mZego = Zego.getInstance(getApplication());
        //初始化用户信息，这些信息本应从服务器读取
        mMyserver.initCurUserInfo(mIsMaster, mRoomInfo, mZego);
        mZego.setHandler(mMyserver);

    }

    private int checkFinished(Chess[][] board) {
        boolean hasRedShuai = false, hasBlackShuai = false;
        for (Chess[] rows : board) {
            for (Chess chess : rows) {
                if (chess == null) continue;
                if (chess.type == Chess.ChessType.RED_SHUAI)
                    hasRedShuai = true;
                else if (chess.type == Chess.ChessType.BLACK_SHUAI)
                    hasBlackShuai = true;
            }
        }
        //0,没结束，1红方胜利，2黑方胜利
        if (!hasBlackShuai) return 1;
        if (!hasRedShuai) return 2;
        return 0;

    }

    public void showFinished(boolean isRedWin) {
        if (isRedWin) {
            if (chessView.isRed()) showRestartDialog("我方胜利！");
            else showRestartDialog("我方失败！");
        } else {
            if (chessView.isRed()) showRestartDialog("我方失败！");
            else showRestartDialog("我方胜利！");

        }
    }

    public void sendBoardMsg(Chessboard chessboard, int fromX, int fromY, int toX, int toY) {
        int state = checkFinished(chessboard.board);

        Msg msg = MsgBoard.chessboard2Msg(chessboard, mUserId, fromX, fromY, toX, toY);
        mZego.sendMsg(mRoomId, userList, msg);
        if (state > 0) {
            showFinished(state == 1);
        }
    }

    /**
     * 收到棋盘更新消息
     */
    @Override
    public void onChessboardMsg(MsgBoard msg) {
        Chess[][] chessboard = msg.toChess(chessView.isRed());
        int state = checkFinished(chessboard);

        chessView.updateBoard(chessboard, msg.isRedPlaying, msg.fromX, msg.fromY, msg.toX, msg.toY);
        if (state > 0) {
            showFinished(state == 1);
        }
    }

    private void updateHeader() {
        if (mIsMaster) {
            mMyHeader.setImageResource(R.drawable.user1);
            if (chessView.userCount <= 1) {
                mOtherUserHeader.setImageResource(R.drawable.none);
            } else {
                mOtherUserHeader.setImageResource(R.drawable.user2);
            }
        } else {
            mMyHeader.setImageResource(R.drawable.user2);
            mOtherUserHeader.setImageResource(R.drawable.user1);
        }


    }

    @Override
    public void onAddUser(ArrayList<ZegoUser> userList) {
        super.onAddUser(userList);
        for (ZegoUser user : userList) {
            this.userList.add(user);
        }
        chessView.updateUserCount(userList.size());
        updateHeader();
        if (chessView.userCount == 2) {
            chessView.restart();
        }
    }

    @Override
    public void onDelUser(ArrayList<ZegoUser> userList) {
        super.onDelUser(userList);
        for (ZegoUser user : userList) {
            for (ZegoUser u2 : this.userList) {
                if (user.userID.equals(u2.userID)) {
                    this.userList.remove(u2);
                    break;
                }
            }
        }
        chessView.updateUserCount(-userList.size());
        if (mIsMaster && chessView.userCount <= 1) {

            toast("对手退出，重新开始！");
            showTip("等待对手...");
            chessView.clearChess();
        }
        updateHeader();
    }

    public void restart(View view) {
        if (chessView.userCount > 1)
            showRestartDialog("确定重新开局？");
        else
            toast("请等待对手进入房间！");
    }

    public void showRestartDialog(String msg) {
        tipTV.setText(msg);
        ShowUtils.comfirm(this, "游戏结束", msg, "再来一局", this);
    }

    /**
     * 收到来自服务器发送的房间信息
     */
    @Override
    public void onRoomInfo(RoomInfo info) {
        super.onRoomInfo(info);
        mRoomNameTV.setText(info.roomName + "(" + info.roomId + ")");
        mMyserver.updateRoomInfo(info);
        if (info.isLogout) {
            logout(3);
            return;
        }
        mRoomInfo = info;

    }

    @Override
    public void onAddStream(ArrayList<ZegoStream> streamList) {
        super.onAddStream(streamList);
        for (ZegoStream stream : streamList) {
            mZego.pullStream(stream.streamID);
            Log.e(TAG, "拉取流" + stream.streamID);
        }
    }

    @Override
    public void onDelStream(ArrayList<ZegoStream> streamList) {
        super.onDelStream(streamList);
        for (ZegoStream stream : streamList) {
            mZego.stopPullStream(stream.streamID);
        }
    }

    /**
     * 收到“服务器”返回的Token数据
     */
    @Override
    public void onToken(String token) {
        super.onToken(token);
        //登录房间
        mZego.loginRoom(mUserId, mUserName, mRoomId, token);
        //进房间就推流
        mZego.pushStream(mRoomId + "_" + mUserId + "_" + new Random().nextInt());
        //针对观众，如果3秒内没有收到当前房间信息，则表示房主一直处于断网状态，要自动退出
        if (!mIsMaster) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(3 * 1000);
                        if (mRoomInfo == null) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    toast("房主已离线！");
                                    logout(0);
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();

        }
    }


    public void showTip(String msg) {
        tipTV.setText(msg);
    }

    @Override
    public void onOk() {
        chessView.restart();
    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onBackPressed() {
        logout(1);
    }

    //退出房间
    private void performLoginOut() {

        mZego.loginOut(mRoomId);
        finish();
    }

    /**
     * level: 0 :no tips, 1: comfirm , 2:force, 3: login error
     */
    public void logout(int level) {
        if (level == 0) {
            performLoginOut();
        }
        switch (level) {
            case 1: {
                String msg = mIsMaster ? "退出将解散房间，确定退出？" : "确定退出房间？";
                ShowUtils.comfirm(this, "退出房间", msg, "退出房间", new ShowUtils.OnClickOkListener() {
                    @Override
                    public void onOk() {
                        performLoginOut();
                    }

                    @Override
                    public void onCancel() {
                    }
                });
                break;
            }
            case 2:
            case 3: {
                toast("房主已解散房间！");
                performLoginOut();
                break;
            }
        }
    }
}