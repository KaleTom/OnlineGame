package com.zg.onlinegame.chess;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;

import com.zg.onlinegame.R;

public class Chess {
    private static Bitmap[] bmps;
    private boolean mIsRed;
    // 图片 id
//    private int imageId;
    private Bitmap mBmp = null;

    //    private int num;
    // 当前棋在棋盘中的位置，posX 为行，posY 为列
//    private int posX, posY;
    public ChessType type;

    public static void loadBitmaps(Context ctx, int wh) {
        bmps = new Bitmap[14];
        int[] idxs = {R.drawable.rb, R.drawable.rs, R.drawable.rx, R.drawable.rm, R.drawable.rp,
                R.drawable.rz, R.drawable.rj, R.drawable.bb, R.drawable.bs, R.drawable.bx, R.drawable.bm, R.drawable.bp,
                R.drawable.bz, R.drawable.bj};
        for (int i = 0; i < 14; ++i) {
            Bitmap bmp = BitmapFactory.decodeResource(ctx.getResources(), idxs[i]);
            bmps[i] = resizeBmp(bmp, wh, wh);
        }
    }

    public enum ChessType {
        RED_SHUAI((byte) 0), RED_SHI((byte) 1), RED_XIANG((byte) 2), RED_MA((byte) 3), RED_PAO((byte) 4), RED_ZU((byte) 5), RED_CHE((byte) 6),
        BLACK_SHUAI((byte) 7), BLACK_SHI((byte) 8), BLACK_XIANG((byte) 9), BLACK_MA((byte) 10), BLACK_PAO((byte) 11), BLACK_ZU((byte) 12), BLACK_CHE((byte) 13);

        private byte type;

        ChessType(byte type) {
            this.type = type;
        }

        public byte getType() {
            return this.type;
        }
    }

    public Chess(ChessType type) {
        this.mIsRed = type.getType() < ChessType.BLACK_SHUAI.getType();
        this.type = type;
        if (bmps != null)
            this.mBmp = bmps[type.getType()];
//        this.num = num;

        // 黑旗的图片 id
//        int[] blackId = {R.drawable.bb, R.drawable.bs, R.drawable.bx, R.drawable.bm, R.drawable.bj,
//                R.drawable.bp, R.drawable.bz};
//        // 红旗的图片 id
//        int[] redId = {R.drawable.rb, R.drawable.rs, R.drawable.rx, R.drawable.rm, R.drawable.rj,
//                R.drawable.rp, R.drawable.rz};
//        // 所有的棋的种类
//        ChessType[] redTypes = {ChessType.RED_SHUAI, ChessType.RED_SHI, ChessType.RED_XIANG, ChessType.RED_MA,
//                ChessType.RED_CHE, ChessType.RED_PAO, ChessType.RED_ZU};
//
//        ChessType[] blackTypes = {ChessType.BLACK_SHUAI, ChessType.BLACK_SHI, ChessType.BLACK_XIANG, ChessType.BLACK_MA,
//                ChessType.BLACK_CHE, ChessType.BLACK_PAO, ChessType.BLACK_ZU};
//        // 根据当前棋的颜色来匹配不同的图片
//        ChessType[] types = redTypes;
//        int[] ids = redId;
//        if (!this.mIsRed) {
//            types = blackTypes;
//            ids = blackId;
//        }
//
//        for (int i = 0; i < types.length; i++) {
//            if (types[i] == type) {
//                imageId = ids[i];
//                break;
//            }
//        }

    }

    private static Bitmap resizeBmp(Bitmap rootImg, int w, int h) {
        int rW = rootImg.getWidth();
        int rH = rootImg.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(w * 1.0f / rW, h * 1.0f / rH);
        return Bitmap.createBitmap(rootImg, 0, 0, rW, rH, matrix, true);
    }

    public Bitmap getBitmap() {
        if (mBmp == null)
            mBmp = bmps[type.getType()];
        return mBmp;
    }

//    public void setSize(Context ctx, int wh) {
//        Bitmap bmp = BitmapFactory.decodeResource(ctx.getResources(), imageId);
//        mBmp = resizeBmp(bmp, wh, wh);
//    }

    // 获取棋的颜色
    public boolean isRed() {
        return mIsRed;
    }

    // 获取棋名
    public ChessType getType() {
        return type;
    }

    // 获取棋编号
//    public int getNum() {
//        return num;
//    }
    // 获取棋的图片id
//    public int getImageId() {
//        return imageId;
//    }

    // 设置棋的行列坐标
//    public void setPos(int posX, int posY) {
//        this.posX = posX;
//        this.posY = posY;
//    }
//
//    // 设置棋的航坐标
//    public int getPosX() {
//        return posX;
//    }
//
//    // 设置棋的列坐标
//    public int getPosY() {
//        return posY;
//    }

    // 将当前的棋坐标水平翻转
//    public void reverse() {
//        posX = 9 - posX;
//    }
}