package com.zg.onlinegame.entity;

import java.util.ArrayList;


public class RoomInfo extends Msg {
    public String roomName;
    public String roomId;
    public String masterId;
    public boolean isMuted;
    public boolean isLogout;


    public RoomInfo(int msgType, String fromUserId, String roomId, String roomName,
                    String masterId,
                    boolean isMuted, boolean isLogout) {
        super(msgType, fromUserId);
        this.roomId = roomId;
        this.roomName = roomName;
        this.masterId = masterId;
        this.isMuted = isMuted;
        this.isLogout = isLogout;

    }

    @Override
    public String toString() {
        return gson.toJson(this);
    }


}
