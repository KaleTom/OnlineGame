package com.zg.onlinegame.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.zg.onlinegame.R;
import com.zg.onlinegame.entity.UserInfo;
import com.zg.onlinegame.zego.MyServer;


public class MainActivity extends BaseServerEventActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    private EditText mRoomIDEt;
    private EditText mRoomNameEt;
    private Button mCreateRoomBtn;
    private Button mJoinRoomBtn;
    private String mRoomName;
    private String mRoomId;
    private boolean isCreate;
    private MyServer mMyserver;
    private UserInfo curUserInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        setStatusTextColor(true);

        mRoomIDEt = findViewById(R.id.roomIdEt);
        mRoomNameEt = findViewById(R.id.roomNameEt);
        mCreateRoomBtn = findViewById(R.id.createRoomBtn);
        mJoinRoomBtn = findViewById(R.id.joinRoomBtn);

        mCreateRoomBtn.setOnClickListener(this);
        mJoinRoomBtn.setOnClickListener(this);

        mMyserver = MyServer.getInstance();

    }


    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onResume() {
        super.onResume();
        //这里随机创建一个用户，实际项目应当有登录获取用户信息
        curUserInfo = UserInfo.random();
        mMyserver.setServerListener(this);
        Log.e(TAG, "onResume");


    }


    @Override
    public void onClick(View view) {

        mRoomName = mRoomNameEt.getText().toString();
        mRoomId = mRoomIDEt.getText().toString();
        if (mRoomId.length() <= 0) {
            toast("请填写房间ID");
            return;
        }
        if (view == mCreateRoomBtn) {
            if (mRoomName.length() <= 0) {
                toast("请填写房间名称");
                return;
            }
            if (mRoomName.length() > 8) {
                toast("最多8个字符");
                return;

            }
            isCreate = true;
        } else {
            isCreate = false;
        }

        showLoading("正在登录...");
        mMyserver.reqRoomUserCount(this, mRoomId);

    }


    @Override
    protected void onGrantedAllPermission() {
        toRoomActivity();
    }

    private void toRoomActivity() {
        if (isCreate && !checkPermission()) {
            requestPermission();
            return;
        }
        Intent intent = new Intent(this, ChessActivity.class);
        intent.putExtra("roomId", mRoomId);
        intent.putExtra("roomName", mRoomName);
        intent.putExtra("isMaster", isCreate);
        intent.putExtra("userName", curUserInfo.name);
        intent.putExtra("userId", curUserInfo.uid);


        startActivity(intent);
    }


    @Override
    public void onRoomUserCount(int userCount) {
        if (isCreate) {
            if (userCount <= 0)
                toRoomActivity();
            else
                toast("房间ID已存在");
        } else {
            if (userCount <= 0)
                toast("房间ID不存在");
            else if(userCount==1)
                toRoomActivity();
            else
                toast("房间已满员！");
        }
    }


}