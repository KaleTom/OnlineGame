package com.zg.onlinegame.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.zg.onlinegame.activity.ChessActivity;
import com.zg.onlinegame.chess.Chess;
import com.zg.onlinegame.chess.ChessUtils;
import com.zg.onlinegame.chess.Chessboard;

public class ChessView extends View implements View.OnTouchListener {
    private final static String TAG = "ChessView";
    private ChessActivity activity;
    private Chessboard chessboard;
    //    private boolean isWait = true;//是否处于等待状态
    private int selX = -1, selY = -1;
    private int width = -1, height = -1;
    public int userCount = 0;

    public ChessView(ChessActivity context, Chessboard chessboard) {
        super(context);
        this.activity = context;
        this.chessboard = chessboard;
//        isWait = !chessboard.isRed;
        updateWaitTip();
        this.setOnTouchListener(this);
    }

    public void restart() {
        if (width < 0 || height < 0) return;
        chessboard.reset();
        this.chessboard.calcSize(activity, width, height);
//        isWait = !chessboard.isRed;
        selX = selY = -1;
        updateWaitTip();
        postInvalidate();
        activity.sendBoardMsg(chessboard, -1, -1, -1, -1);

    }

    public void updateUserCount(int delta) {
        userCount = userCount + delta >= 0 ? userCount + delta : 0;

    }

    public void clearChess() {
        selY = selX = -1;
        chessboard.clear();
        postInvalidate();
    }

    private void updateWaitTip() {
        if (chessboard.isWaiting()) activity.showTip("等待对方下...");
        else activity.showTip("我方下..");
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        width = right - left;
        height = bottom - top;
        this.chessboard.calcSize(activity, right - left, bottom - top);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        chessboard.draw(canvas, selX, selY);
    }


    private void onClickPos(int x, int y) {
        Log.e(TAG, "userCount:" + userCount);
        if (userCount <= 1) return;// 人数不够，没法开始
        if (x == selX && y == selY) return;
        Chess chess = chessboard.board[y][x];

        //选中自己棋子
        if (chess != null && chess.isRed() == chessboard.isRed) {
            selX = x;
            selY = y;
            postInvalidate();
            return;
        }

        if (chessboard.isWaiting()) return;//处于等待状态，只能选中自己棋子，不能下棋
        //接下来逻辑处理没有选中自己的棋子，或者目标棋子为null
        //如果之前没有选中棋子，那么接下来就不需要再处理了
        if (selX == -1 || selY == -1)
            return;
        //以下逻辑说明之前已经选中了棋子
        boolean canMove = ChessUtils.canMove(chessboard, selX, selY, x, y);
        if (!canMove) return; //不能移动就不要走了
        //以下说明能移动，直接把目标位置替换
//        Chess.ChessType targetShuai = Chess.ChessType.BLACK_SHUAI;
//        if (!chessboard.isRed) targetShuai = Chess.ChessType.RED_SHUAI;
//        boolean isWinner = chess != null && chess.type == targetShuai;
//        if (chess != null)
//            Log.e(TAG, targetShuai + "," + chess.type);

        chessboard.board[y][x] = chessboard.board[selY][selX];
        chessboard.board[selY][selX] = null;
        chessboard.isRedPlaying = !chessboard.isRedPlaying;

        activity.sendBoardMsg(chessboard, selX, selY, x, y);
        selX = x;
        selY = y;
        postInvalidate();
        updateWaitTip();

//        if (isWinner) {
//            activity.showRestartDialog("我方胜利");
//        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            int x = (int) event.getX();
            int y = (int) event.getY();
            Point p = chessboard.getGridPos(x, y);
            if (p == null) return false;
            onClickPos(p.x, p.y);

        }
        return false;
    }

    public void updateBoard(Chess[][] chess, boolean isRedPlaying, int fromX, int fromY, int toX, int toY) {
        chessboard.board = chess;
        chessboard.isRedPlaying = isRedPlaying;
        if (selX >= 0 && selY >= 0) {
            if (chess[selY][selX] == null) {
                selY = selX = -1;
            }
        }
        updateWaitTip();
        postInvalidate();
    }

    public boolean isRed() {
        return chessboard.isRed;
    }
}
