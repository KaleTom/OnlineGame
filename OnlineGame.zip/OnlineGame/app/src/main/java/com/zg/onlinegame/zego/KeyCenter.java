package com.zg.onlinegame.zego;

public class KeyCenter {
    // 控制台地址: https://console.zego.im/dashboard
    // 可以在控制台中获取APPID，并将APPID设置为long型，例如：APPID = 123456789L.
    public static long APPID = ;  //这里填写APPID
    // 在控制台找到ServerSecret，并填入如下
    public static String SERVER_SECRET = ; //这里填写服务器端密钥

}
