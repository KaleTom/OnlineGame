package com.zg.onlinegame.chess;

public class ChessUtils {
    private static boolean canShuaiMove(Chessboard chessboard, int fromX, int fromY, int toX, int toY) {
        // 1. 只能直线移动
        if (fromX != toX && fromY != toY)
            return false;
        //2. 只能移动一格
        if (Math.abs(toX - fromX) != 1 && Math.abs(toY - fromY) != 1)
            return false;
        //3. 确保在田字格里面
        if (toX < 3 || toX > 5 || toY < 7 || toY > 9)
            return false;
        Chess[][] board = chessboard.board;
        //4. 确保没有跟对面的帅直连
        for (int i = 0; i < 3; ++i) {
            if (board[i][toX] != null && (board[i][toX].type == Chess.ChessType.RED_SHUAI || board[i][toX].type == Chess.ChessType.BLACK_SHUAI))
                return false;
        }
        return true;

    }

    private static boolean canShiMove(Chessboard chessboard, int fromX, int fromY, int toX, int toY) {
        // 不能直线移动
        if (fromX == toX || fromY == toY)
            return false;
        // 只能移动一格
        if (Math.abs(fromX - toX) != 1 || Math.abs(fromY - toY) != 1)
            return false;
        // 只可在田字中移动
        if (toX < 3 || toX > 5 || toY < 7 || toY > 9)
            return false;
        return true;
    }

    private static boolean canXiangMove(Chessboard chessboard, int fromX, int fromY, int toX,
                                        int toY) {
        // 不可以过河，越界
        if (toY <= 4)
            return false;
        // 只能走田字
        if (Math.abs(fromX - toX) != 2 || Math.abs(fromY - toY) != 2) {
            return false;
        }
        // 是否被挡住了
        return chessboard.board[(fromY + toY) / 2][(fromX + toX) / 2] == null;
    }

    private static boolean canMaMove(Chessboard chessboard, int fromX, int fromY, int toX,
                                     int toY) {
        // 只能走 日 字
        if (Math.abs(fromY - toY) * Math.abs(fromY - toY) + Math.abs(fromX - toX) * Math.abs(fromX - toX) != 5)
            return false;
        // 向下走时
        if (toY - fromY == 2 && chessboard.board[fromY + 1][fromX] != null) {
            return false;
        } else if (toY - fromY == -2 && chessboard.board[fromY - 1][fromX] != null) {// 向上走时
            return false;
        } else if (toX - fromX == 2 && chessboard.board[fromY][fromX + 1] != null) {// 向右走时
            return false;
        } else if (toX - fromX == -2 && chessboard.board[fromY][fromX - 1] != null) {// 向左走时
            return false;
        }
        return true;
    }

    private static int countLine(Chessboard chessboard, int a, int b1, int b2, boolean isY) {
        if (b1 > b2) {
            int t = b1;
            b1 = b2;
            b2 = t;
        }
        int count = 0;
        for (int i = b1 + 1; i < b2; ++i) {
            if (isY) {
                if (chessboard.board[i][a] != null) {
                    count += 1;
                }
            } else {
                if (chessboard.board[a][i] != null) {
                    count += 1;
                }

            }
        }
        return count;
    }

    private static boolean canCheMove(Chessboard chessboard, int fromX, int fromY, int toX,
                                      int toY) {
        // 只能直线移动
        if (fromX != toX && fromY != toY)
            return false;
        int count;

        if (fromY == toY) {  // 左右走
            count = countLine(chessboard, fromY, fromX, toX, false);
        } else {
            count = countLine(chessboard, fromX, fromY, toY, true);
        }
        return count == 0;
    }

    private static boolean canPaoMove(Chessboard chessboard, int fromX, int fromY, int toX,
                                      int toY) {

        // 只能直线移动
        if (fromX != toX && fromY != toY)
            return false;
        int count = 0;
        if (fromY == toY) {  // 左右走
            count = countLine(chessboard, fromY, fromX, toX, false);
        } else {
            count = countLine(chessboard, fromX, fromY, toY, true);
        }
        if (count > 1) return false;
        if (count == 1) {
            //因为外围已经验证过目标位置必须是空或者是对方子，所以只要不是null就可以
            if (chessboard.board[toY][toX] == null)
                return false;
        }
        return true;
    }


    private static boolean canZuMove(Chessboard chessboard, int fromX, int fromY, int toX,
                                     int toY) {
        // 只能往前走
        if (toY > fromY)
            return false;
        // 若过河了
        if (fromY <= 4) {
            // 只能走直线
            if (fromY != toY && fromX != toX)
                return false;
            // 只能走一格
            if (Math.abs(fromX - toX) != 1 && fromY - toY != 1)
                return false;
        } else {
            // 若没有过河，则只能前走一格
            if (fromX != toX || fromY - toY != 1)
                return false;
        }
        return true;
    }

    // 判断是否可以移动
    public static boolean canMove(Chessboard chessboard, int fromX, int fromY, int toX, int toY) {
        //不能原地走
        if (fromX == toX && fromY == toY)
            return false;

        Chess chess = chessboard.board[fromY][fromX];
        // 首先，确保目标位置不是自己的子
        Chess[][] board = chessboard.board;
        if (board[toY][toX] != null && board[toY][toX].isRed() == chessboard.isRed) {
            return false;
        }

        switch (chess.type) {
            case RED_SHUAI:
            case BLACK_SHUAI:
                return canShuaiMove(chessboard, fromX, fromY, toX, toY);
            case RED_SHI:
            case BLACK_SHI:
                return canShiMove(chessboard, fromX, fromY, toX, toY);
            case RED_XIANG:
            case BLACK_XIANG:
                return canXiangMove(chessboard, fromX, fromY, toX, toY);
            case RED_MA:
            case BLACK_MA:
                return canMaMove(chessboard, fromX, fromY, toX, toY);
            case RED_CHE:
            case BLACK_CHE:
                return canCheMove(chessboard, fromX, fromY, toX, toY);
            case RED_PAO:
            case BLACK_PAO:
                return canPaoMove(chessboard, fromX, fromY, toX, toY);
            case RED_ZU:
            case BLACK_ZU:
                return canZuMove(chessboard, fromX, fromY, toX, toY);
        }

        return true;
    }
}
