package com.zg.onlinegame.chess;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.util.Log;

public class Chessboard {
    private final static String TAG = "Chessboard";
    private Paint paint = new Paint();
    // 棋盘10行9列
    public Chess[][] board;
    // 当前用户是否是红色
    public boolean isRed;
    //当前是否是红色方下棋
    public boolean isRedPlaying;
    // 边缘的padding
    private int pad;
    float cvsOX = -1;
    float cvsOY = -1;
    int gridWH = -1;

    int borderW = 8;
    int borderMargin = 5;
    Path gridPath;
    Path borderPath;

    public Chessboard(boolean isRed, int pad) {
        this.isRed = isRed;
        this.pad = pad;

        reset();
    }

    public void clear() {
        for (int i = 0; i < 10; ++i) {
            for (int j = 0; j < 9; ++j)
                board[i][j] = null;
        }
    }

    public boolean isWaiting() {
        return (isRed && !isRedPlaying) || (!isRed && isRedPlaying);
    }

    public Point getGridPos(int x, int y) {
        int half = gridWH / 2;
        float xx = x - (cvsOX - half);
        float yy = y - (cvsOY - half);
        if (xx < 0 || xx > 9 * gridWH || yy < 0 || yy > 10 * gridWH)
            return null;
//        Log.e("TEST", (xx * 1.0 / gridWH) + "," + (yy * 1.0 / gridWH));
        x = (int) Math.floor(xx * 1.0 / gridWH);
        y = (int) Math.floor(yy * 1.0 / gridWH);
        return new Point(x, y);
    }

    public void draw(Canvas canvas, int selX, int selY) {
        paint.setColor(Color.rgb(230, 180, 130));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        //先绘制网格
        paint.setStrokeWidth(3);
        canvas.drawPath(gridPath, paint);
        paint.setStrokeWidth(8);
        canvas.drawPath(borderPath, paint);


        for (int y = 0; y < board.length; ++y) {
            for (int x = 0; x < board[0].length; ++x) {
                drawChess(canvas, board[y][x], x, y);
            }
        }
        if (selX >= 0 && selY >= 0) {
            drawSel(canvas, selX, selY);
        }
    }

    public void reset() {
        board = new Chess[10][9];
        isRedPlaying = true;
        // 将，两士，两相，两马，两车，两炮，五卒
        // 32 个棋子在地图上的 x 坐标，红棋先
        // 前16个棋的 x 坐标
        int[] xArr = {4, 3, 5, 2, 6, 1, 7, 0, 8, 1, 7, 0, 2, 4, 6, 8};
        // 前16个棋的 y 坐标
        int[] yArr1 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 3, 3, 3, 3, 3};
        int[] yArr2 = {9, 9, 9, 9, 9, 9, 9, 9, 9, 7, 7, 6, 6, 6, 6, 6};
        // 前16个棋的棋名
        Chess.ChessType[] rtypes = {
                Chess.ChessType.RED_SHUAI, Chess.ChessType.RED_SHI, Chess.ChessType.RED_SHI, Chess.ChessType.RED_XIANG, Chess.ChessType.RED_XIANG,
                Chess.ChessType.RED_MA, Chess.ChessType.RED_MA, Chess.ChessType.RED_CHE, Chess.ChessType.RED_CHE, Chess.ChessType.RED_PAO, Chess.ChessType.RED_PAO,
                Chess.ChessType.RED_ZU, Chess.ChessType.RED_ZU, Chess.ChessType.RED_ZU, Chess.ChessType.RED_ZU, Chess.ChessType.RED_ZU};

        Chess.ChessType[] btypes = {
                Chess.ChessType.BLACK_SHUAI, Chess.ChessType.BLACK_SHI, Chess.ChessType.BLACK_SHI, Chess.ChessType.BLACK_XIANG, Chess.ChessType.BLACK_XIANG,
                Chess.ChessType.BLACK_MA, Chess.ChessType.BLACK_MA, Chess.ChessType.BLACK_CHE, Chess.ChessType.BLACK_CHE, Chess.ChessType.BLACK_PAO, Chess.ChessType.BLACK_PAO,
                Chess.ChessType.BLACK_ZU, Chess.ChessType.BLACK_ZU, Chess.ChessType.BLACK_ZU, Chess.ChessType.BLACK_ZU, Chess.ChessType.BLACK_ZU};

        int[] redYArr = yArr1;
        int[] blackYArr = yArr2;

        if (isRed) {
            redYArr = yArr2;
            blackYArr = yArr1;
        }
        //初始化所有棋子
        for (int i = 0; i < xArr.length; ++i) {
            int ry = redYArr[i];
            int by = blackYArr[i];
            int x = xArr[i];
            board[ry][x] = new Chess(rtypes[i]);
            board[by][x] = new Chess(btypes[i]);
        }

    }

    private void resetGridPath() {

        gridPath = new Path();
        for (int i = 0; i < 9; ++i) {
            if (i > 0 && i < 8) {
                addLine(gridPath, i, 0, i, 4);
                addLine(gridPath, i, 5, i, 9);
            } else {
                addLine(gridPath, i, 0, i, 9);
            }
        }
        for (int i = 0; i < 10; ++i) {
            addLine(gridPath, 0, i, 8, i);
        }
        addLine(gridPath, 3, 0, 5, 2);
        addLine(gridPath, 5, 0, 3, 2);
        addLine(gridPath, 3, 9, 5, 7);
        addLine(gridPath, 5, 9, 3, 7);
        for (int i = 0; i < 5; ++i) {
            int type = 0;
            if (i == 0) type = 1;
            if (i == 4) type = 2;
            addPosLine(gridPath, i * 2, 3, type);
            addPosLine(gridPath, i * 2, 6, type);

        }
        addPosLine(gridPath, 1, 2, 0);
        addPosLine(gridPath, 7, 2, 0);
        addPosLine(gridPath, 1, 7, 0);
        addPosLine(gridPath, 7, 7, 0);

        borderPath = new Path();
        borderPath.addRect(cvsOX - borderW - borderMargin,
                cvsOY - borderMargin - borderW,
                cvsOX + 8 * gridWH + borderMargin + borderW,
                cvsOY + 9 * gridWH + borderMargin + borderW, Path.Direction.CW);

    }

    public void calcSize(Context context, int canvasW, int canvasH) {

        int gridY = (int) ((canvasH - 2 * pad) / 10);
        int gridX = (int) ((canvasW - 2 * pad) / 9);
        gridWH = gridX < gridY ? gridX : gridY;
        cvsOX = (canvasW - 8 * gridWH) / 2;
        cvsOY = (canvasH - 9 * gridWH) / 2;
        Chess.loadBitmaps(context, gridWH);
//        for (int i = 0; i < board.length; ++i) {
//            for (int j = 0; j < board[0].length; ++j) {
//                if (board[i][j] != null) {
//                    board[i][j].setSize(context, gridWH);
//                }
//            }
//        }
        //重置棋盘网格Path
        resetGridPath();

    }

    private void addLine(Path path, int fromX, int fromY, int toX, int toY) {
        path.moveTo(cvsOX + fromX * gridWH, cvsOY + fromY * gridWH);
        path.lineTo(cvsOX + toX * gridWH, cvsOY + toY * gridWH);
    }

    private void lineTo(Path path, int toX, int toY) {
        path.lineTo(cvsOX + toX * gridWH, cvsOY + toY * gridWH);
    }

    private void addPosLine(Path path, int x, int y, int type) {
        float small = 0.08f * gridWH;
        float large = 0.24f * gridWH;
        float cx = cvsOX + x * gridWH;
        float cy = cvsOY + y * gridWH;
        if (type == 0 || type == 1) {//绘制右半边
            float xx = cx + small;
            path.moveTo(xx, cy - large);
            path.lineTo(xx, cy - small);
            path.lineTo(cx + large, cy - small);
            path.moveTo(xx, cy + large);
            path.lineTo(xx, cy + small);
            path.lineTo(cx + large, cy + small);
        }
        if (type == 0 || type == 2) {//绘制左半边
            float xx = cx - small;
            path.moveTo(xx, cy - large);
            path.lineTo(xx, cy - small);
            path.lineTo(cx - large, cy - small);
            path.moveTo(xx, cy + large);
            path.lineTo(xx, cy + small);
            path.lineTo(cx - large, cy + small);

        }
    }

    private void drawChess(Canvas canvas, Chess chess, int x, int y) {
        if (chess == null) return;
        Bitmap bmp = chess.getBitmap();
        float xx = cvsOX + x * gridWH - gridWH / 2.0f;
        float yy = cvsOY + y * gridWH - gridWH / 2.0f;
        canvas.drawBitmap(bmp, xx, yy, paint);

    }

    private void drawSel(Canvas canvas, int x, int y) {
        float half = gridWH / 2.0f;
        float hhalf = half / 2.0f;
        float xx = cvsOX + x * gridWH;
        float yy = cvsOY + y * gridWH;
        Path path = new Path();
        path.moveTo(xx - half, yy - hhalf);
        path.lineTo(xx - half, yy - half);
        path.lineTo(xx - hhalf, yy - half);

        path.moveTo(xx - half, yy + hhalf);
        path.lineTo(xx - half, yy + half);
        path.lineTo(xx - hhalf, yy + half);

        path.moveTo(xx + hhalf, yy - half);
        path.lineTo(xx + half, yy - half);
        path.lineTo(xx + half, yy - hhalf);

        path.moveTo(xx + hhalf, yy + half);
        path.lineTo(xx + half, yy + half);
        path.lineTo(xx + half, yy + hhalf);
        paint.setStrokeWidth(5);
        paint.setColor(Color.RED);
        canvas.drawPath(path, paint);
    }

}
