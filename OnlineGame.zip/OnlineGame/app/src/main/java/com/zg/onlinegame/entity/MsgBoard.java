package com.zg.onlinegame.entity;

import com.zg.onlinegame.chess.Chess;
import com.zg.onlinegame.chess.Chessboard;

public class MsgBoard extends Msg {
    public boolean isRedPlaying; //接下来是否是红方下棋
    public byte[][] board; //当前棋局面
    public int fromX;
    public int fromY;
    public int toX;
    public int toY;

    public MsgBoard(int msgType, String fromUserId, boolean isRedPlaying, byte[][] board, int fromX, int fromY, int toX, int toY) {
        super(msgType, fromUserId);
        this.board = board;
        this.isRedPlaying = isRedPlaying;
        this.fromX = fromX;
        this.fromY = fromY;
        this.toX = toX;
        this.toY = toY;
    }


    public static MsgBoard chessboard2Msg(Chessboard chessboard, String fromUserId, int fromX, int fromY, int toX, int toY) {
        Chess[][] chess = chessboard.board;
        byte[][] board = new byte[10][9];
        for (int i = 0; i < 10; ++i) {
            for (int j = 0; j < 9; ++j) {
                if (chess[i][j] == null)
                    if (chessboard.isRed)
                        board[i][j] = -1;
                    else
                        board[9 - i][8 - j] = -1;
                else {
                    if (chessboard.isRed)
                        board[i][j] = chess[i][j].type.getType();
                    else
                        board[9 - i][8 - j] = chess[i][j].type.getType();
                }
            }
        }

        return new MsgBoard(MsgType.MSG_BOARD, fromUserId, chessboard.isRedPlaying, board, fromX, fromY, toX, toY);
    }

    public Chess[][] toChess(boolean isRed) {
        Chess[][] chess = new Chess[10][9];
        for (int i = 0; i < 10; ++i) {
            for (int j = 0; j < 9; ++j) {
                if (board[i][j] >= 0) {
                    if (isRed)
                        chess[i][j] = chgByteType2Chess(board[i][j]);
                    else
                        chess[9 - i][8 - j] = chgByteType2Chess(board[i][j]);

                } else {
                    if (isRed)
                        chess[i][j] = null;
                    else
                        chess[9 - i][8 - j] = null;
                }
            }
        }
        return chess;
    }

    private Chess chgByteType2Chess(byte type) {
        Chess.ChessType ctype = Chess.ChessType.RED_CHE;
        Chess.ChessType[] all = {
                Chess.ChessType.RED_CHE,
                Chess.ChessType.RED_SHUAI,
                Chess.ChessType.RED_SHI,
                Chess.ChessType.RED_XIANG,
                Chess.ChessType.RED_MA,
                Chess.ChessType.RED_PAO,
                Chess.ChessType.RED_ZU,
                Chess.ChessType.RED_CHE,
                Chess.ChessType.BLACK_SHUAI,
                Chess.ChessType.BLACK_SHI,
                Chess.ChessType.BLACK_XIANG,
                Chess.ChessType.BLACK_MA,
                Chess.ChessType.BLACK_PAO,
                Chess.ChessType.BLACK_ZU,
                Chess.ChessType.BLACK_CHE
        };
        for (Chess.ChessType t : all) {
            if (t.getType() == type) {
                ctype = t;
                break;
            }
        }
        return new Chess(ctype);
    }


    @Override
    public String toString() {
        return gson.toJson(this);
    }
}
